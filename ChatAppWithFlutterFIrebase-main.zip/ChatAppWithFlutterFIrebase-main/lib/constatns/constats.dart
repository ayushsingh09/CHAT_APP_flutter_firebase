class constatns {
  static String senderId = 'senderId';
  static String senderEmail = 'senderEmail';
  static String reciverId = 'reciverId';
  static String message = 'message';
  static String timestamp = 'timestamp';
  constatns._();
}
